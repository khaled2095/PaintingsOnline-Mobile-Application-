//
//  UIColor+Random.swift
//  YBSlantedCollectionViewLayoutSample
//
//  Created by Yassir Barchi on 30/12/2017.
//  Copyright © 2017 Yassir Barchi. All rights reserved.
//

import Foundation
