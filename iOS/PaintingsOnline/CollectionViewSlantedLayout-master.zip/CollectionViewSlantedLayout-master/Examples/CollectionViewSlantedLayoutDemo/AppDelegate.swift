//
//  AppDelegate.swift
//  CollectionViewSlantedLayoutDemo
//
//  Created by Yassir Barchi on 28/02/2016.
//  Copyright © 2016 Yassir Barchi. All rights reserved.
//

import UIKit

@UIApplicationMain
class AppDelegate: UIResponder, UIApplicationDelegate {

    var window: UIWindow?

    func application(_ application: UIApplication,
                     didFinishLaunchingWithOptions launchOptions: [UIApplication.LaunchOptionsKey: Any]?) -> Bool {
        // Override point for customization after application launch.
        return true
    }

}
